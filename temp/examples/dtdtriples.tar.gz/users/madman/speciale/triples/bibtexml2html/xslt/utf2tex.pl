#!/usr/local/bin/perl -w
#This programs converts UTF-8 charactres into LaTeX special characters
#Usage: perl recode.xml > tmp.xml

select STDERR;

#Reading the input file
#$text = "";
LINE:
while (<>){

# usage of this table:
#s/utf-8-code/Latex-code/g;

#--------------------------
#Transformation table:
#--------------------------

# Inverted Exclamation Mark
s/&#161;/\!'/g;
# Inverted Question Mark
s/&#191;/\?'/g;
# Section Sign
s/&#167;/\{\\S\}/g;


# Latin Capital Ligature OE
s/&#140;/\{\\OE\}/g;

# Latin Small Capital Ligature oe
s/&#156;/\{\\oe\}/g;


# Latin Capital Letter A With Grave
s/&#192;/\{\\`A\}/g;

# Latin Capital Letter A With Acute
s/&#193;/\{\\'A\}/g;

# Latin Capital Letter A With Circumflex
s/&#194;/\{\\^A\}/g;

# Latin Capital Letter A With Tilde
s/&#195;/\{\\~A\}/g;

# Latin Capital Letter A With Diaeresis (germ. A Umlaut)
s/&#196;/\\{\"A}/g;

# Latin Capital Letter A With Ring Above
s/&#197;/\r\{A\}/g;

# Latin Capital Ligature AE
s/&#198;/\{\\AE\}/g;

# Latin Capital Letter C With Cedilla
s/&#199;/c\{C\}/g;

# Latin Capital Letter E With Grave
s/&#200;/\{\\`E\}/g;

# Latin Capital Letter E With Acute
s/&#201;/\{\\'E\}/g;

# Latin Capital Letter E With Circumflex
s/&#202;/\{\\^E\}/g;

# Latin Capital Letter E With Diaeresis
s/&#203;/\{\\"E\}/g;

# Latin Capital Letter I With Grave
s/&#204;/\{\\`I\}/g;

# Latin Capital Letter I With Acute
s/&#205;/\{\\'I\}/g;

# Latin Capital Letter I With Circumflex
s/&#206;/\{\\^I\}/g;

# Latin Capital Letter I With Diaeresis
s/&#207;/\{\\"I\}/g;

# Latin Capital Letter D With Stroke
s/&#208;/\{\\DH\}/g;

# Latin Capital Letter N With Tilde
s/&#209;/\{\\~N\}/g;

# Latin Capital Letter O With Grave
s/&#210;/\{\\`O\}/g;

# Latin Capital Letter O With Acute
s/&#211;/\{\\'O\}/g;

# Latin Capital Letter O With Circumflex
s/&#212;/\{\\^O\}/g;

# Latin Capital Letter O With Tilde
s/&#213;/\{\\~O\}/g;

# Latin Capital Letter O With Diaeresis (germ. O Umlaut)
s/&#214;/\{\\"O\}/g;

# Latin Capital Letter O With Stroke
s/&#216;/\{\\O\}/g;

# Latin Capital Letter U With Grave
s/&#217;/\{\\`U\}/g;

# Latin Capital Letter U With Acute
s/&#218;/\{\\'U\}/g;

# Latin Capital Letter U With Circumflex
s/&#219;/\{\\^U\}/g;

# Latin Capital Letter U With Diaeresis (germ. U Umlaut)
s/&#220;/\{\\"U\}/g;

# Latin Capital Letter Y With Acute
s/&#221;/\{\\'Y\}/g;

# Latin Capital Letter Thorn
s/&#222;/\{\\TH\}/g;


# Latin Small Letter Sharp S
s/&#223;/\{\\ss\}/g;


# Latin Small Letter a With Grave
s/&#224;/\{\\`a\}/g;

# Latin Small Letter a With Acute
s/&#225;/\{\\'a\}/g;

# Latin Small Letter a With Circumflex
s/&#226;/\{\\^a\}/g;

# Latin Small Letter a With Tilde
s/&#227;/\{\\~a\}/g;

# Latin Small Letter a With Diaeresis (germ. a Umlaut)
s/&#228;/\{\\"a\}/g;

# Latin Samll Letter a With Ring Above
s/&#229;/\r\{a\}/g;

# Latin Small Ligature ae
s/&#230;/\{\\ae\}/g;

# Latin Small Letter c With Cedilla
s/&#231;/c\{c\}/g;

# Latin Small Letter e With Grave
s/&#232;/\{\\`e\}/g;

# Latin Small Letter e With Acute
s/&#233;/\{\\'e\}/g;

# Latin Small Letter e With Circumflex
s/&#234;/\{\\^e\}/g;

# Latin Small Letter e With Diaeresis
s/&#235;/\{\\"e\}/g;

# Latin Small Letter i With Grave
s/&#236;/\{\\`i\}/g;

# Latin Small Letter i With Acute
s/&#237;/\{\\'i\}/g;

# Latin Small Letter i With Circumflex
s/&#238;/\{\\^i\}/g;

# Latin Small Letter i With Diaeresis
s/&#239;/\{\\"i\}/g;

# Latin Small Letter n With Stroke
s/&#240;/\{\\dh\}/g;

# Latin Small Letter n With Tilde
s/&#241;/\{\\~n\}/g;

# Latin Small Letter o With Grave
s/&#242;/\{\\`o\}/g;

# Latin Small Letter o With Acute
s/&#243;/\{\\'o\}/g;

# Latin Small Letter o With Circumflex
s/&#244;/\{\\^o\}/g;

# Latin Small Letter o With Tilde
s/&#245;/\{\\~o\}/g;

# Latin Small Letter u With Diaeresis (germ. o Umlaut)
s/&#246;/\{\\"o\}/g;

# Latin Capital Letter O With Stroke
s/&#248;/\{\\o\}/g;

# Latin Small Letter u With Grave
s/&#249;/\{\\`u\}/g;

# Latin Small Letter u With Acute
s/&#250;/\{\\'u\}/g;

# Latin Small Letter u With Circumflex
s/&#251;/\{\\^u\}/g;

# Latin Small Letter u With Diaeresis (germ. u Umlaut)
s/&#252;/\{\\"u\}/g;

# Latin Small Letter y With Acute
s/&#253;/\{\\'y\}/g;

# Latin Small Letter Thorn
s/&#254;/\{\\th\}/g;

# Latin Small Letter y With Diaeresis
s/&#255;/\{\\"y\}/g;


# Latin Capital letter C with Acute 
s/&#262;/\{\\'C\}/g;

# Latin Small letter c with Acute 
s/&#263;/\{\\'c\}/g;

# Latin Capital letter C with Carom
s/&#268;/\\v\{C\}/g;

# Latin Small letter c with Caron
s/&#269;/\\v\{c\}/g;

# Latin Capital letter L with Stroke
s/&#321;/\{\\L\}/g;

# Latin Small letter l with Stroke
s/&#322;/\{\\l\}/g;

# Latin Capital letter N with Acute
s/&#323;/\{\\'N\}/g;

# Latin Small Letter n With Acute
s/&#324;/\{\\'n\}/g;

# Latin Small letter r with Caron
s/&#345;/\\v\{r\}/g;

# Latin Capital Letter S With Acute
s/&#346;/\{\\'S\}/g;

# Latin Small Letter s With Acute
s/&#347;/\{\\'s\}/g;

# Latin Capital Letter Z With Acute
s/&#377;/\{\\'Z\}/g;

# Latin Small Letter z With Acute
s/&#378;/\{\\'z\}/g;

# Latin Capital Letter Z With Dot Above
#s/&#379;/\{\\'Z\}/g;

# Latin Small Letter z With Dot Above
#s/&#380;/\{\\'z\}/g;

# Latin Capital letter Z with Carom
s/&#8470;/\\v\{Z\}/g;

# Latin Small letter z with Caron
s/&#381;/\\v\{z\}/g;



#Printing error messages for not recognised unicode symbols
select STDERR;

while (/(&#\w+\;)/g){  
    print "WARNING - don't now how to convert the following unicode symbol: $1\n";
}

select STDOUT;

print $_;
}
