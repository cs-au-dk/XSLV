file: README.txt
date: 2002-September-09

===============================================================
Content:
===============================================================
1. Files you need
2. Abstract
3. General Notes 
4. Requirements


===============================================================
1. Files you need:
===============================================================
The "xml2html.zip" package contains the following files:

 1) xml2html.xsl:    XML to HTML converter.
 2) xml2bibhtml.xsl: XML to HTML converter
                     (generates multiple HTML files; each
                      containing a single BibTeX entry).
 3) xml2bib.xsl:     XML to BibTeX converter
                     (converts XML back to the BibTeX-format).
 4) recode.xsl:      XML to XML converter
                     (converts utf-8 to us-ascii).
 5) bibtexml.dtd:    The Document Type Definition for the XML file
 6) definitions.xml: An XML-file holding all necessary variables
                     and information about your categories.
 7) styles.css:      (optional) changing the size and/or the style
                     of the fonts used is possible by modifying
                     the settings in this file.
 8) utf2tex.pl:      Converts utf-8 special characters back to
                     LaTeX characters.
 9) rem_colon.pl:    Replaces the colons in all BibTeX labels
                     with an underscore.
10) add_colon.pl:    Resets the original colon in the label field.
11) makehtml:        A shellscript, generating all HTML files.
12) makebib:         A shellscript, converting XML backto the
                     BibTeX-format.
13) README.txt:      This file.
14) HOWTO.txt:       Detailed description about how to prepare your
                     BibTeX file and how to process the tool files.
15) Six icons:       ps.gif; ps_gz.gif; pdf.gif; home.gif;
   [in folder pic/]  html.gif; bibtex.gif.
16) COPYING.txt      This software tool is free software.
                     It is distributed under the terms of the
                     GNU GENERAL PUBLIC LICENSE.
                     This file contains the full liscence text
                     about the terms and conditions for copying,
                     distributing and modification.
		     


===============================================================
Abstract:
===============================================================

The main goal of the BibTeX-XML-HTML Bibliography Project
is to transform a BibTeX bibliography into an HTML file
to facilitate the publication of the bibliography on the web. 

The BibTeX-XML-HTML Project tools will first transform
your BibTeX file into an XML file. The advantage of the
XML format is that it is standardized, platform
independent and used universally. Furthermore, it is
easily edited and managed with XML tools and translated
into HTML (or text files) with the XSLT stylesheet language.

In the next step, the tool will generate multiple HTML files
out of the XML representation of your bibliography
(all these files will be generated automatically
with just one call): 


=> An HTML representation of your BibTeX-file,
   "list.html". 
   This file lists ALL entries from your BibTeX-file
   in Cambridge-like style. 

=> Several different HTML files categorized according to
   subject - each file contains a subject of its own. 


The format of these HTML files is the same, which means
that all available additional functions are the same in
each catalogue. 
Each list in these HTML files is divided into two columns.
The right column contains an alphabetical list of papers.
For each entry in the right column, there is a citation key
in standard citation format (e.g., [Richter, 2000])
in the left column. Under each citation key you find
up to six clickable icons that provide additional
functions for the paper: 

1) An icon that will bring you to a separate page
   containing a complete BibTeX entry of the paper for
   pasting it into your own BibTeX file.
2) An icon to download the paper in postscript format.
3) An icon to download the paper in gzipped postscript
   format.
4) An icon to download the paper in PDF format for
   Acrobat Reader.
5) An icon that will bring you to a webpage with an abstract
   of the paper or with additional information on it.
6) An icon that will bring you to the homepage of the
   first author of the paper.


In addition, the tool generates:  
=> A graphical overview table "overview.html"
   of the available thematic subjects.  
=> HTML-files, one for each BibTeX entry.
   These files contains a single entry in its orginal
   BibTeX format.

To use the full range of capabilities the tool offers,
you just have to mark the entries in your BibTeX file
with a thematic Id. Next, you declare these thematic
categories in a separate XML file "definitions.xml".
You will find a detailed description on how to prepare
your BibTeX files and handle the project files in the file
"HOWTO.txt".

You will find another how-to description together with
some examples on my websit at:
http://www.authopilot.com/xml/howto.html




===============================================================
3. General Notes:
===============================================================
- The XSL stylesheet uses some XPath functions and elements
  which might be unknown to some old XSLT Parsers.
  => I have tested this sotware package with Xsltproc and Saxon
     (ver. 7.1 or later).
     Other XSLT parser might work too, but I can`t guarantee.

- The XSL stylesheet translates all LaTeX special characters
  into the international UTF-8 character set, which supports
  a wide range of special characters.
  The most recent releases of the most frequently used
  browsers, including Mozilla, Netscape (6.x/7.x), and
  IExplorer, support this format.
  If you are using an older browser (like all Netscape (4.x)),
  under Solaris Platform however, you might not be able to see
  non-standard characters displayed correctly
  (e.g. Netscape (4.x) display them as question marks).
  If you experience difficulties, please upgrade to a
  newer browser.

- Make sure that you do not use any special characters in
  your BibTeX file without signing them as special charcters
  in LaTeX.
  (e.g. using such characters in a url will cause an error
   by the parser!)

- Make sure that your BibTeX-file is syntactically correct.

- Sorting the BibTex entries:
  Note that the tool will not (yet) sort your BibTex entries!
  If you want to have sorted entries (e.g. by names) in the
  output HTML files, please sort the entries in your BibTeX
  file BEFORE you convert the BibTeX file to XML.
  To sort your BibTeX file just use BibTeX tools or editors
  with a BibTeX sort option (e.g. Emacs or Xemacs). 

- The stylesheet does NOT (yet) support the following
  LaTeX/BibTeX formats:

    + BibTeX "crossrefs": Make sure to have complete entry
      fields inside an entry!

    + LaTeX commands like "/cite", "/it", "/sc", ... will
      be ignored by the parser and be printed just like
      normal characters.

    + Inside the "author" or "editor" field, abbreviations
      like "@macro" or "@string" will be ignored by the parser.
      (Abbreviations in all other fields are ok!)

    + Colons inside a BibTeX label:
      These colons (e.g. "@book{reed:99") may cause an error
      with some parsers (e.g. with Saxon; Xsltproc will ignore
      these colons!)
      If you encounter any errors during the parsing process
      then try to replace these colons with an underscore. 
      There is a Perl script in the xml2html.zip package that
      will do this job for you.
      (Note that this is only a temporarily replacement.
      It will have no effect to the output HTML files!)



===============================================================
4. Requirements:
===============================================================
To use the stylesheets you just need:

- An XSLT Parser.
  The package works well with these two parsers:
  >> Xsltproc - A free XSLT parser (based on C) from the free
     XSLT C library for Gnome.
     http://xmlsoft.org/XSLT/
  >> Saxon (Version 7.1 or later)
     The free XSLT Parser based on Java (Saxon 7.1 requires
     JDK 1.2 or later) from Michael Kay.
     http://saxon.sf.net/

- Perl running on your machine.
