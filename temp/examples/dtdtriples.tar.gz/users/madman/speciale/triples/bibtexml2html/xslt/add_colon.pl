#!/usr/bin/perl -w

# usage: add_colon.pl < input-file > output-file


@lines = <STDIN>;

foreach $elem (@lines)
  {if (index($elem, "@") == 0)
	  {
	    $elem =~ s/_/:/g;
	  }
    print "$elem";
  }

