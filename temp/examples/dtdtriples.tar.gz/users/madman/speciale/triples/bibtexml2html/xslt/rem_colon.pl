#!/usr/bin/perl -w

# usage: rem_colon.pl < Eingabedatei > Ausgabedatei

@lines = <STDIN>;

foreach $line (@lines)
  {
    $bl = index($line, "<");
    @parts = split(" ", $line);
    foreach $elem (@parts)
      {
	if (index($elem, "label") == 0)
	  {
	    $elem =~ s/:/_/g;
	  }
      }
    print (" " x $bl);
    print "@parts\n";
  }
