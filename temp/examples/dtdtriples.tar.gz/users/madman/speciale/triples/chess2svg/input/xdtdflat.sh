#!/bin/sh
# xdtdflat.sh,v 1.3 2000/02/13 17:34:08 sar Exp

export SP_CHARSET_FIXED=YES 
export SP_ENCODING=XML
export SGML_CATALOG_FILES=../xml/xml.soc:../catalog:$SGML_CATALOG_FILES
perl ../scripts/dtdflat.pl chess.dtd chess.flat.dtd dummy.xml
